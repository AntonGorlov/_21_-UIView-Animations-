//
//  ViewController.h
//  HomeWork Lesson 21 (UIView Animations)
//
//  Created by Anton Gorlov on 16.01.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

