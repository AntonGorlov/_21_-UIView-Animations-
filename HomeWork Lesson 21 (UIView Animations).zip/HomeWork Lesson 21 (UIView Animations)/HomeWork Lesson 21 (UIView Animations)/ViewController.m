//
//  ViewController.m
//  HomeWork Lesson 21 (UIView Animations)
//
//  Created by Anton Gorlov on 16.01.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak,nonatomic) UIView* square1;
@property (weak,nonatomic) UIView* square2;
@property (weak,nonatomic) UIView* square3;
@property (weak,nonatomic) UIView* square4;
@property (weak,nonatomic) UIView* cornerView1;
@property (weak,nonatomic) UIView* cornerView2;
@property (weak,nonatomic) UIView* cornerView3;
@property (weak,nonatomic) UIView* cornerView4;

//соз анимацию из картинок

@property (weak,nonatomic) UIImageView* animal;


@end

@implementation ViewController
/*
 Ученик.
 
 1. Создайте 4 вьюхи у левого края ипада.
 2. Ваша задача всех передвинуть горизонтально по прямой за одно и тоже время
 3. Для каждой вьюхи используйте свою интерполяцию (EasyInOut, EasyIn и т.д.). Это для того, чтобы вы увидели разницу своими собственными глазами :)
 4. Добавте реверсивную анимацию и бесконечные повторения
 5. добавьте смену цвета на рандомный

 Студент
 
 5. Добавьте еще четыре квадратные вьюхи по углам - красную, желтую, зеленую и синюю
 6. За одинаковое время и при одинаковой интерполяции двигайте их всех случайно, либо по, либо против часовой стрелки в другой угол.
 7. Когда анимация закончиться повторите все опять: выберите направление и передвиньте всех :)
 8. Вьюха должна принимать в новом углу цвет той вьюхи, что была здесь до него ;)
 
 Мастер
 
 8. Нарисуйте несколько анимационных картинок человечка, который ходит.
 9. Добавьте несколько человечков на эту композицию и заставьте их ходить
 
 Супермена на этот раз нет, ничего сверхъестественного не смог придумать :(
 */


 //соз 4 вьюхи


- (void)viewDidLoad {
#pragma mark- Views
    [super viewDidLoad];
    

    
    UIView*view1=[[UIView alloc]initWithFrame:CGRectMake(0, 100, 60, 60)];
    view1.backgroundColor=[UIColor redColor];
    //add view
    [self.view addSubview:view1];
    self.square1=view1;//наше property
    
    
    UIView*view2=[[UIView alloc]initWithFrame:CGRectMake(0, 170, 60, 60)];
    view2.backgroundColor=[UIColor grayColor];
    [self.view addSubview:view2];
    self.square2=view2;
    
    
    UIView*view3=[[UIView alloc]initWithFrame:CGRectMake(0, 240, 60, 60)];
    view3.backgroundColor=[UIColor blueColor];
    [self.view addSubview:view3];
    self.square3=view3;
    
    UIView*view4=[[UIView alloc]initWithFrame:CGRectMake(0, 310, 60, 60)];
    view4.backgroundColor=[UIColor magentaColor];
    [self.view addSubview:view4];
    self.square4=view4;
    
#pragma mark- picture cat's
    
    UIImageView*cat=[[UIImageView alloc]initWithFrame:CGRectMake(100, 800, 200, 180)];  //соз анимацию из картинок
    cat.backgroundColor=[UIColor clearColor];
    [self.view addSubview:cat];
    self.animal=cat;
    
    UIImageView*cat2=[[UIImageView alloc]initWithFrame:CGRectMake(260, 700, 150, 110)];  //соз анимацию из картинок
    cat2.backgroundColor=[UIColor clearColor];
    [self.view addSubview:cat2];
    self.animal=cat2;
    
    UIImageView*cat3=[[UIImageView alloc]initWithFrame:CGRectMake(370, 600, 100, 90)];  //соз анимацию из картинок
    cat3.backgroundColor=[UIColor clearColor];
    [self.view addSubview:cat3];
    self.animal=cat3;
    
    UIImageView*cat4=[[UIImageView alloc]initWithFrame:CGRectMake(480, 550, 70, 50)];  //соз анимацию из картинок
    cat4.backgroundColor=[UIColor clearColor];
    [self.view addSubview:cat4];
    self.animal=cat4;
    
    UIImageView*cat5=[[UIImageView alloc]initWithFrame:CGRectMake(560, 500, 45, 30)];  //соз анимацию из картинок
    cat5.backgroundColor=[UIColor clearColor];
    [self.view addSubview:cat5];
    self.animal=cat5;
    
   // UIImage*image1=[UIImage imageNamed:@"1.png"];
    UIImage*image2=[UIImage imageNamed:@"2.png"];
   // UIImage*image3=[UIImage imageNamed:@"3.png"];
    UIImage*image4=[UIImage imageNamed:@"4.png"];
    UIImage*image5=[UIImage imageNamed:@"5.png"];
   // UIImage*image6=[UIImage imageNamed:@"6.png"];
    UIImage*image7=[UIImage imageNamed:@"7.png"];
   
   // UIImage*image8=[UIImage imageNamed:@"8.png"];
   // UIImage*image9=[UIImage imageNamed:@"9.png"];
   // UIImage*image10=[UIImage imageNamed:@"10.png"];
 
    UIImage*image11=[UIImage imageNamed:@"11.png"];
    //UIImage*image12=[UIImage imageNamed:@"12.png"];
    
    
    
    NSArray*arrayPeople =[NSArray arrayWithObjects:image4,image5,image7,image2,image11, nil];
    
    cat.animationImages =arrayPeople;
    cat.animationDuration =1.f;
    [self.view addSubview:cat];
    self.animal=cat;
    [cat startAnimating];
    
    cat2.animationImages =arrayPeople;
    cat2.animationDuration =1.f;
    [self.view addSubview:cat2];
    self.animal=cat2;
    [cat2 startAnimating];
    
    cat3.animationImages =arrayPeople;
    cat3.animationDuration =1.f;
    [self.view addSubview:cat3];
    self.animal=cat3;
    [cat3 startAnimating];
    
    cat4.animationImages =arrayPeople;
    cat4.animationDuration =0.3f;
    [self.view addSubview:cat4];
    self.animal=cat4;
    [cat4 startAnimating];
    
    cat5.animationImages =arrayPeople;
    cat5.animationDuration =0.2f;
    [self.view addSubview:cat5];
    self.animal=cat5;
    [cat5 startAnimating];
    //self.animal.transform = CGAffineTransformMakeScale(4, 2);

    
    
//add cornerViews
#pragma mark- CornerViews
    
    UIView*cornerSquare1=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 60, 60)];
    cornerSquare1.backgroundColor=[UIColor redColor];
    [self.view addSubview:cornerSquare1];
    self.cornerView1=cornerSquare1;
 
    UIView*cornerSquare2=[[UIView alloc]initWithFrame:CGRectMake(708, 0, 60, 60)];
    cornerSquare2.backgroundColor=[UIColor yellowColor];
    [self.view addSubview:cornerSquare2];
    self.cornerView2=cornerSquare2;
 
    UIView*cornerSquare3=[[UIView alloc]initWithFrame:CGRectMake(708, 964, 60, 60)];
    cornerSquare3.backgroundColor=[UIColor greenColor];
    [self.view addSubview:cornerSquare3];
    self.cornerView3=cornerSquare3;
 
    UIView*cornerSquare4=[[UIView alloc]initWithFrame:CGRectMake(0, 964, 60, 60)];
    cornerSquare4.backgroundColor=[UIColor blueColor];
    [self.view addSubview:cornerSquare4];
    self.cornerView4=cornerSquare4;


}

#pragma mark- randomColor

-(UIColor*) randomColor {
    CGFloat r =[self randomFromZeroToOne];
    CGFloat g =[self randomFromZeroToOne];
    CGFloat b =[self randomFromZeroToOne];
    return [UIColor colorWithRed:r green:g blue:b alpha:1.f];
}
-(CGFloat) randomFromZeroToOne { //убираем дублирование кода
    return (CGFloat) (arc4random()%256)/255.f;
}


-(void) viewDidAppear:(BOOL)animated {
      [super viewDidAppear:animated];
    
      [self moveCornerViews:self.cornerView1];
    //ставим картинку
    //[self moveCornerViews:_people];
    
    
#pragma mark- Animated
    
    [UIView animateWithDuration:3
                          delay:1
                        options:UIViewAnimationOptionCurveEaseInOut
                              | UIViewAnimationOptionRepeat
                              | UIViewAnimationOptionAutoreverse
                     animations:^{
                         self.square1.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(self.square1.frame)/2, 130);
                         self.square1.backgroundColor = [self randomColor];
                         
                     }
                     completion:^(BOOL finished) {
                         NSLog(@"finished 1 %d",finished);
                     }];
    
    [UIView animateWithDuration:3
                          delay:1
                        options:UIViewAnimationOptionCurveEaseIn
                              | UIViewAnimationOptionRepeat
                              | UIViewAnimationOptionAutoreverse
                     animations:^{
                         self.square2.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(self.square2.frame)/2, 200);
                         self.square2.backgroundColor = [self randomColor];

                     }
                     completion:^(BOOL finished) {
                         NSLog(@"finished 2 %d",finished);
                     }];
    [UIView animateWithDuration:3
                          delay:1
                        options:UIViewAnimationOptionCurveEaseOut
     | UIViewAnimationOptionRepeat
     | UIViewAnimationOptionAutoreverse
                     animations:^{
                         self.square3.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(self.square3.frame)/2, 270);
                         self.square3.backgroundColor = [self randomColor];

                     }
                     completion:^(BOOL finished) {
                         NSLog(@"finished 3 %d",finished);
                     }];
    [UIView animateWithDuration:3
                          delay:1
                        options:UIViewAnimationOptionCurveLinear
     | UIViewAnimationOptionRepeat
     | UIViewAnimationOptionAutoreverse
                     animations:^{
                         self.square4.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(self.square4.frame)/2, 340);
                         self.square4.backgroundColor = [self randomColor];

                     }
                     completion:^(BOOL finished) {
                         NSLog(@"finished 4 %d",finished);
                     }];


    }
 

-(void) moveCornerViews:(UIView*) view {
    
    //1-й шаг угловых квадратиков
    [UIView animateWithDuration:3
                          delay:0
                        options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionRepeat
                        animations:^{
                           self.cornerView1.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(self.cornerView1.frame)/2,30);
                           self.cornerView1.backgroundColor = [self randomColor];
                            self.cornerView2.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(self.cornerView2.frame)/2,995);
                            self.cornerView2.backgroundColor = [self randomColor];
                            self.cornerView3.center=CGPointMake(30, 995);
                            self.cornerView3.backgroundColor = [self randomColor];
                            self.cornerView4.center=CGPointMake(30, 30);
                            self.cornerView4.backgroundColor = [self randomColor];
                            
                     }
                     completion:^(BOOL finished) {
                        
                     }];
    //2-й шаг угловых квадратиков
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:3
                              delay:0
                            options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionRepeat
                         animations:^{
                             self.cornerView1.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(self.cornerView1.frame)/2, 995);
                             self.cornerView1.backgroundColor = [self randomColor];
                             self.cornerView2.center=CGPointMake(30, 995);
                             self.cornerView2.backgroundColor = [self randomColor];
                             self.cornerView3.center=CGPointMake(30, 30);
                             self.cornerView3.backgroundColor = [self randomColor];
                             self.cornerView4.backgroundColor = [self randomColor];
                             self.cornerView4.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(self.cornerView4.frame)/2,30);

                         }
                         completion:^(BOOL finished) {
                             NSLog(@"Corner animated finished, %d",finished);
                         }];

    });
    //3-й шаг угловых квадратиков
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:3
                              delay:0
                            options:UIViewAnimationOptionCurveLinear
                         animations:^{
                             self.cornerView1.center=CGPointMake(30, 995);
                             self.cornerView1.backgroundColor = [self randomColor];
                             self.cornerView2.center=CGPointMake(30, 30);
                             self.cornerView2.backgroundColor = [self randomColor];
                             self.cornerView3.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(self.cornerView3.frame)/2,30);
                             self.cornerView3.backgroundColor = [self randomColor];
                             self.cornerView4.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(self.cornerView4.frame)/2, 995);
                             self.cornerView4.backgroundColor = [self randomColor];
                         }
                         completion:^(BOOL finished) {
                             NSLog(@"cornerView1 animated finished, %d",finished);
                         }];
        
        
    });
    //4-й шаг угловых квадратиков
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(9 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:3
                              delay:0
                            options:UIViewAnimationOptionCurveLinear | UIViewAnimationOptionRepeat
                         animations:^{
                             self.cornerView1.center=CGPointMake(30, 30);
                             self.cornerView1.backgroundColor = [self randomColor];
                             self.cornerView2.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(self.cornerView2.frame)/2,30);
                             self.cornerView2.backgroundColor = [self randomColor];
                             self.cornerView3.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(self.cornerView3.frame)/2, 995);
                             self.cornerView3.backgroundColor = [self randomColor];
                             self.cornerView4.center=CGPointMake(30, 995);
                             self.cornerView4.backgroundColor = [self randomColor];
                             
                         }
                         completion:^(BOOL finished) {
                             NSLog(@"cornerView1 animated finished, %d",finished);
                         }];
        
        
    });

 
    

}

-(void) viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
