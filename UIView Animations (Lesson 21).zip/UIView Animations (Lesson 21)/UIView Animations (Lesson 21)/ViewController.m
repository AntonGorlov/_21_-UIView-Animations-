//
//  ViewController.m
//  UIView Animations (Lesson 21)
//
//  Created by Anton Gorlov on 13.01.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
//@property (weak,nonatomic) UIView* testView;
//создадим анимацию с картинок
@property (weak,nonatomic) UIImageView* testImageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIImageView* view =[[UIImageView alloc]initWithFrame:CGRectMake(100, 100, 50, 50)];
    view.backgroundColor=[UIColor clearColor];
    
    //соз 3 картинки
   UIImage* image1=[UIImage imageNamed:@"1.jpg"];
   UIImage* image2=[UIImage imageNamed:@"2.jpg"];
   UIImage* image3=[UIImage imageNamed:@"3.jpg"];
    
   NSArray*images=[NSArray arrayWithObjects:image1,image2,image3, nil];
    
    view.animationImages = images;
    
    view.animationDuration=1.f;
    
    [self.view addSubview:view];
    [view startAnimating];

    //self.testView=view;
    self.testImageView=view;
    
}
-(UIColor*) randomColor {
    CGFloat r= (CGFloat) (arc4random()%256)/255.f;
    CGFloat g= (CGFloat) (arc4random()%256)/255.f;
    CGFloat b= (CGFloat) (arc4random()%256)/255.f;
    return [UIColor colorWithRed:r green:g blue:b alpha:1.f];
}

-(void) moveView:(UIView*) view { // сделали универсальную функцию (скопировали и вставил в др.проект -будет работать)
    
    //создадим случайную точку в пределах видимости (случайные движения вьюхи)
    
    CGRect rect=self.view.bounds; //мы двигаем вью в нашем родительском значит берем bounds
    //перезапишем наш rect (сделаем вставку) это мы сделали отступ в нашем внутри нашего view и будем определять нашу рендoмную точку
    rect = CGRectInset(rect, CGRectGetWidth(view.frame), CGRectGetHeight(view.frame));
    //сгенерируем нашу точку
    CGFloat x = arc4random() % (int)CGRectGetWidth(rect)+CGRectGetMinX(rect);
    CGFloat y = arc4random() % (int)CGRectGetHeight(rect)+CGRectGetMinY(rect);
    
    //сделаем рендомный scale
    CGFloat scale2=(float)(arc4random() % 151)/100.f+0.5f;
    
    // крутим view генерируем число от "0" до 2х"Пи"
    CGFloat rotation2=(float)(arc4random() % (int)(M_PI * 2 * 10000))/10000-M_PI;
    
    //сгенерируем Duration
    CGFloat duration2=(float)(arc4random() % 20001)/10000+2;//сгенерируем от 2 до 4 секунд
    
    [UIView animateWithDuration:duration2
                          delay:0
                        options:UIViewAnimationOptionCurveLinear //|UIViewAnimationOptionRepeat |UIViewAnimationOptionAutoreverse //маски движения анимации
                     animations:^{
                         view.center=CGPointMake(x, y);
                         //view.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(view.frame)/2, 150);
                         view.backgroundColor=[self randomColor];
                         
                         CGAffineTransform scale=CGAffineTransformMakeScale(scale2, scale2);
                         CGAffineTransform Rotation=CGAffineTransformMakeRotation(rotation2);
                         //складываем матрицы с помощью  функции "конкотанации"
                         CGAffineTransform transform=CGAffineTransformConcat(scale, Rotation);
                         view.transform=transform;
                         
                         /*
                          //поворачиваем фигуру на угол "Пи".
                          self.testView.transform=CGAffineTransformMakeRotation(M_PI);
                          //изменение размеров фигуры (в ширину и длину) (в количестве раз!!!)
                          self.testView.transform=CGAffineTransformMakeScale(4, 2);
                          */
                     }
                     completion:^(BOOL finished) {
                         NSLog(@"Animation finished. %d" ,finished);
                        // NSLog(@"\n view frame=%@ \n view bounds= %@",NSStringFromCGRect(self.testView.frame),NSStringFromCGRect(self.testView.bounds));
                         __weak UIView*v=view;
                         [self moveView:v];
                         
                     }];
    /*
     //отмена анимации через 6 секунд
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
     });
     
     */
    



}


-(void) viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
/*
    //создание анимационного блока
    [UIView animateWithDuration:2
                     animations:^{
                         //center - точка,относительно середины frame
                         self.testView.center=CGPointMake(CGRectGetWidth(self.view.bounds)-CGRectGetWidth(self.testView.frame)/2, 150);//так как мы передвигаем центр,то надо еще отнять половину ширины и теперь прямоугольник доходит до края экрана
                     }];
*/
    
    //[self moveView:self.testView];
    [self moveView:self.testImageView];
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
